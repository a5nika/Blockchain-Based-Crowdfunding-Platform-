// app.js
let web3;
let factoryContract;
let campaignContract;

// Replace with your deployed factory address from Truffle migrate output
const factoryAddress = "0x610aCa2925128F4722144aeE4C69b14114325054";

// Load ABI files from Truffle build folder
const factoryABI = fetch("../build/contracts/CampaignFactory.json")
  .then(res => res.json());
const campaignABI = fetch("../build/contracts/Campaign.json")
  .then(res => res.json());

window.addEventListener("load", async () => {
  if (typeof window.ethereum !== "undefined") {
    try {
      // Request wallet access
      await window.ethereum.request({ method: "eth_requestAccounts" });
      web3 = new Web3(window.ethereum);

      console.log("✅ MetaMask connected");
      const accounts = await web3.eth.getAccounts();
      console.log("Active account:", accounts[0]);

      // Initialize contracts
      const [factoryData, campaignData] = await Promise.all([factoryABI, campaignABI]);
      factoryContract = new web3.eth.Contract(factoryData.abi, factoryAddress);
      window.factoryContract = factoryContract;
      window.campaignABI = campaignData.abi;

      console.log("✅ Factory initialized:", factoryAddress);

      setupUI();
    } catch (err) {
      console.error("❌ User denied wallet access", err);
      alert("Please connect MetaMask to use the DApp.");
    }
  } else {
    alert("❌ MetaMask not detected! Install it to continue.");
  }
});

function setupUI() {
  // --- CREATE CAMPAIGN ---
  document.getElementById("createBtn").onclick = async () => {
    const goal = document.getElementById("goal").value;
    const duration = document.getElementById("duration").value;
    const accounts = await web3.eth.getAccounts();

    try {
      await factoryContract.methods.createCampaign(
        web3.utils.toWei(goal, "ether"),
        duration
      ).send({ from: accounts[0] });

      const campaigns = await factoryContract.methods.getAllCampaigns().call();
      const last = campaigns[campaigns.length - 1];
      console.log("🎯 New campaign created at:", last);
      alert("Campaign created at: " + last);
    } catch (err) {
      console.error(err);
      alert("❌ Failed to create campaign");
    }
  };

  // --- DONATE ---
  document.getElementById("donateBtn").onclick = async () => {
    const address = document.getElementById("campaignAddress").value;
    const amount = document.getElementById("amount").value;
    const accounts = await web3.eth.getAccounts();

    campaignContract = new web3.eth.Contract(window.campaignABI, address);
    await campaignContract.methods.donate().send({
      from: accounts[0],
      value: web3.utils.toWei(amount, "ether")
    });
    alert("✅ Donation successful!");
  };

  // --- WITHDRAW ---
  document.getElementById("withdrawBtn").onclick = async () => {
    const address = document.getElementById("campaignAddress").value;
    const accounts = await web3.eth.getAccounts();
    campaignContract = new web3.eth.Contract(window.campaignABI, address);
    await campaignContract.methods.withdraw().send({ from: accounts[0] });
    alert("💸 Funds withdrawn successfully!");
  };

  // --- REFUND ---
  document.getElementById("refundBtn").onclick = async () => {
    const address = document.getElementById("campaignAddress").value;
    const accounts = await web3.eth.getAccounts();
    campaignContract = new web3.eth.Contract(window.campaignABI, address);
    await campaignContract.methods.refund().send({ from: accounts[0] });
    alert("🔁 Refund successful!");
  };
}
